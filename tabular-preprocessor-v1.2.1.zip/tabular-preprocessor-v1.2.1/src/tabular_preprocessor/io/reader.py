from glob import glob
from pathlib import Path

import polars as pl

from ..config import InputConfig


def _expand(patterns: tuple[str, ...], suffix: str) -> list[str]:
    found: list[str] = []
    for raw in patterns:
        path = Path(raw)
        if path.is_dir():
            found.extend(str(p) for p in sorted(path.rglob(suffix)))
        else:
            found.extend(sorted(glob(raw, recursive=True)))
    return list(dict.fromkeys(found))


def discover_inputs(config: InputConfig) -> dict[str, list[str]]:
    suffix = {"parquet": "*.parquet", "csv": "*.csv", "ipc": "*.ipc"}[config.format]
    if config.layout == "files":
        paths = _expand(config.paths, suffix)
        if not paths:
            raise FileNotFoundError(f"No {config.format} files found: {config.paths}")
        return {"__all__": paths}
    if config.layout == "sample_directories":
        root = Path(config.paths[0])
        patterns = {sample: (str(root / sample / config.file_pattern),) for sample in config.samples}
    else:
        patterns = config.sample_paths
    result = {sample: _expand(paths, suffix) for sample, paths in patterns.items()}
    for sample, paths in result.items():
        if not paths:
            raise FileNotFoundError(f"No {config.format} files for sample '{sample}': {patterns[sample]}")
    return result


def _scan(paths: list[str], config: InputConfig) -> pl.LazyFrame:
    if config.format == "parquet":
        return pl.scan_parquet(paths)
    if config.format == "csv":
        return pl.scan_csv(paths, separator=config.csv_separator)
    return pl.scan_ipc(paths)


def read_lazy(
    config: InputConfig,
    data: pl.DataFrame | pl.LazyFrame | None = None,
    discovered: dict[str, list[str]] | None = None,
) -> pl.LazyFrame:
    if data is not None:
        lf = data.lazy() if isinstance(data, pl.DataFrame) else data
    else:
        discovered = discovered or discover_inputs(config)
        scans = [(sample, _scan(paths, config)) for sample, paths in discovered.items() if sample != "__all__"]
        if scans:
            schemas = {sample: frame.collect_schema() for sample, frame in scans}
            reference_name, reference = next(iter(schemas.items()))
            for sample, schema in schemas.items():
                conflicts = {name: (str(reference[name]), str(schema[name])) for name in set(reference) & set(schema) if reference[name] != schema[name]}
                if conflicts:
                    raise TypeError(f"Incompatible schemas for samples '{reference_name}' and '{sample}': {conflicts}")
        frames = [frame.with_columns(pl.lit(sample).alias(config.sample_column)) for sample, frame in scans]
        lf = pl.concat(frames, how="diagonal_relaxed") if frames else _scan(discovered["__all__"], config)
    if config.columns:
        columns = list(config.columns)
        if config.layout != "files" and config.sample_column not in columns:
            columns.append(config.sample_column)
        lf = lf.select(columns)
    if config.row_index:
        lf = lf.with_row_index(config.row_index)
    return lf
