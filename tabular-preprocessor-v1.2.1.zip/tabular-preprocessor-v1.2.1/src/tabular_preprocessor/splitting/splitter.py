from itertools import accumulate

import polars as pl

from ..config import SplitConfig, TaskConfig


def split(lf: pl.LazyFrame, config: SplitConfig, task: TaskConfig) -> pl.LazyFrame:
    sample = config.sample_column
    groups = list(config.group_columns) or ([config.group_column] if config.group_column else [])
    if config.method == "none":
        return lf.with_columns(pl.lit(config.allowed_samples[0]).alias(sample))
    if config.method == "existing":
        found = set(lf.select(pl.col(sample).unique()).collect().get_column(sample).to_list())
        unknown = found - set(config.allowed_samples)
        missing = set(config.allowed_samples) - found
        if unknown:
            raise ValueError(f"Unknown samples: {sorted(unknown)}")
        if missing:
            raise ValueError(f"Missing samples: {sorted(missing)}")
        return lf
    if config.method in {"random", "stratified", "group"}:
        if config.method == "group":
            unit = pl.struct(groups)
        else:
            unit = pl.int_range(0, pl.len())
            if config.method == "stratified":
                unit = pl.struct([unit.alias("row"), pl.col(task.target)])
        u = unit.hash(seed=config.seed).mod(1_000_000).truediv(1_000_000)
        limits = list(accumulate(config.fractions))[:-1]
        expr = pl.lit(config.allowed_samples[-1])
        for label, limit in reversed(list(zip(config.allowed_samples[:-1], limits))):
            expr = pl.when(u < limit).then(pl.lit(label)).otherwise(expr)
        return lf.with_columns(expr.alias(sample))

    date = config.date_column or task.date_column
    date_expr = pl.col(date).str.to_date(strict=False) if lf.collect_schema()[date] == pl.String else pl.col(date).cast(pl.Date)
    if config.method == "group_temporal":
        group_date = lf.group_by(groups).agg(date_expr.max().alias("__group_date"))
        lf = lf.join(group_date, on=groups, how="left", nulls_equal=True)
        date_expr = pl.col("__group_date")
    expr = pl.lit(config.allowed_samples[-1])
    for label, boundary in reversed(list(zip(config.allowed_samples[:-1], config.boundaries))):
        expr = pl.when(date_expr <= pl.lit(boundary).str.to_date()).then(pl.lit(label)).otherwise(expr)
    lf = lf.with_columns(expr.alias(sample))
    return lf.drop("__group_date") if config.method == "group_temporal" else lf
