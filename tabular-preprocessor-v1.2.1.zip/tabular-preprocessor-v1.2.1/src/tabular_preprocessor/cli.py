import argparse
import importlib.util
from pathlib import Path

from .config import ProjectConfig
from .pipeline import Pipeline
from .progress import ConsoleProgress


def load_config(path: str) -> ProjectConfig:
    spec = importlib.util.spec_from_file_location("preprocessor_user_config", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if not isinstance(module.CONFIG, ProjectConfig):
        raise TypeError("Config module must export CONFIG: ProjectConfig")
    return module.CONFIG


def main() -> None:
    parser = argparse.ArgumentParser(description="Polars-native tabular preprocessing")
    parser.add_argument("config", type=Path)
    args = parser.parse_args()
    config = load_config(str(args.config))
    callback = ConsoleProgress() if config.progress.enabled and config.progress.display in {"auto", "console"} else None
    result = Pipeline(config, progress_callback=callback).run()
    print(result.manifest_path)


if __name__ == "__main__":
    main()
