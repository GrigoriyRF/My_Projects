import json
import platform
import shutil
from dataclasses import asdict, dataclass, replace
from datetime import UTC, datetime
from hashlib import sha256
from pathlib import Path
from time import perf_counter
from uuid import uuid4

import polars as pl

from .checks import check_drift, check_quality, evaluate_gates, new_category_rate
from .config import ProjectConfig, SplitConfig
from .io import discover_inputs, input_fingerprint, read_lazy
from .io.writer import commit, staging_directory, write_dataset
from .lineage import compare_baseline, load_baseline
from .profiling import profile
from .progress import ProgressTracker
from .quarantine import write_quarantine
from .reports import save_reports
from .rules import evaluate_rules
from .schema import compare_schema, infer_roles, validate_schema
from .schema.numbers import normalize_numbers
from .splitting import split
from .transformations import PipelineState, fit, transform, transformation_issues


@dataclass(frozen=True)
class RunResult:
    output_path: Path
    manifest_path: Path
    state_path: Path
    rows: int
    files: int
    status: str = "passed"
    quarantined_rows: int = 0


class Pipeline:
    def __init__(self, config: ProjectConfig, state: PipelineState | None = None, progress_callback=None):
        config.validate()
        self.config = config
        self.state = state
        self.progress = ProgressTracker(config.progress, progress_callback)
        self._stage = "initialization"
        self.last_failed_path: Path | None = None

    @classmethod
    def from_state(cls, config: ProjectConfig, path: str | Path, progress_callback=None) -> "Pipeline":
        return cls(config, PipelineState.load(path), progress_callback)

    def _effective_config(self) -> ProjectConfig:
        if self.config.input.layout == "files":
            return replace(self.config, split=replace(self.config.split, group_columns=self.config.split.group_columns or self.config.identity.group_key))
        samples = self.config.input.samples or tuple(self.config.input.sample_paths)
        split_config = SplitConfig(method="existing", sample_column=self.config.input.sample_column, allowed_samples=samples)
        return replace(self.config, split=split_config)

    def _begin(self, stage: str, message: str, **kwargs) -> None:
        self._stage = stage
        self.progress.start(stage, message, **kwargs)

    def _end(self, stage: str, message: str, **kwargs) -> None:
        self.progress.complete(stage, message, **kwargs)

    def _process(self, data, baseline) -> dict:
        config = self._effective_config()
        discovered = None
        self._begin("input_discovery", "Поиск входных файлов")
        if data is None:
            discovered = discover_inputs(config.input)
        file_count = sum(map(len, (discovered or {}).values()))
        self._end("input_discovery", "Входные файлы найдены", current=file_count, total=file_count)

        self._begin("reading", "Чтение данных и fingerprint")
        lf = read_lazy(config.input, data, discovered)
        fingerprint = input_fingerprint(lf, config.input, config.task, discovered)
        row_id = config.input.row_index or "__tp_row_id"
        if row_id not in lf.collect_schema():
            lf = lf.with_row_index(row_id)
        self._end("reading", "Источник подключён", details={"rows": fingerprint["rows"], "files": file_count})

        self._begin("schema_validation", "Проверка схемы")
        lf, schema_issues = validate_schema(lf, config.schema, config.task)
        current_schema = {name: str(dtype) for name, dtype in lf.collect_schema().items() if name != row_id}
        expected = config.schema.expected_schema or (baseline or {}).get("schema", {})
        schema_issues += compare_schema(current_schema, expected, config.schema)
        self._end("schema_validation", "Схема проверена", details={"issues": len(schema_issues)})

        self._begin("role_inference", "Определение ролей колонок")
        lf = split(lf, config.split, config.task)
        train_name = config.samples.fit_sample or ("train" if "train" in config.split.allowed_samples else config.split.allowed_samples[0])
        if train_name not in config.split.allowed_samples:
            raise ValueError(f"samples.fit_sample: неизвестная выборка {train_name}")
        required_keys = set(c for key in (config.identity.row_key, config.identity.entity_key, config.identity.group_key, config.identity.business_key, config.identity.technical_columns) for c in key)
        required_keys |= set(config.task.available_after_prediction)
        if config.task.prediction_time_column:
            required_keys.add(config.task.prediction_time_column)
        missing_keys = required_keys - set(lf.collect_schema().names())
        if missing_keys:
            raise ValueError(f"Колонки контракта отсутствуют: {sorted(missing_keys)}")
        fit_source = lf.filter(pl.col(config.split.sample_column) == train_name)
        if not fit_source.select(pl.len()).collect().item():
            raise ValueError(f"Обучающая выборка пуста: {train_name}")
        self.role_decisions = []
        identity_roles = {c: "id" for c in required_keys}
        identity_roles.update({c: "technical" for c in config.identity.technical_columns})
        identity_roles.update({c: "excluded" for c in config.task.available_after_prediction})
        identity_roles.update(config.schema.explicit_roles)
        roles = infer_roles(fit_source, replace(config.schema, explicit_roles=identity_roles), config.task, self.role_decisions)
        for decision in self.role_decisions:
            decision["fit_sample"] = train_name
        self.numeric_parse_report = []
        from .schema.numbers import numeric_text, parse_number
        source_schema = lf.collect_schema()
        parsed_columns = [c for c, role in roles.items() if role == "numeric" and source_schema[c] == pl.String]
        if parsed_columns:
            report = lf.group_by(config.split.sample_column).agg(pl.len().alias("__checked_rows"), *[(numeric_text(pl.col(c), config.schema).is_not_null() & parse_number(pl.col(c), config.schema).is_null()).sum().alias(c) for c in parsed_columns]).collect()
            self.numeric_parse_report = [{"column": c, "sample": r[config.split.sample_column], "checked_rows": r["__checked_rows"], "invalid_values": r[c], "action": config.schema.numeric_parse_errors} for r in report.to_dicts() for c in parsed_columns]
        lf = normalize_numbers(lf, roles, config.schema)
        schema_issues += [{"check": "ambiguous_role", "severity": "warning", "column": c, "sample": None, "row_id": None, "reason": "Role requires review; original values retained", "recommended_action": "set schema.explicit_roles"} for c, r in roles.items() if r == "unknown"]
        roles.pop(row_id, None)
        if config.split.sample_column in roles:
            roles[config.split.sample_column] = "technical"
        self.role_decisions = [{**d, "role": roles[d["column"]], "requires_review": roles[d["column"]] == "unknown"} for d in self.role_decisions if d["column"] in roles]
        self._end("role_inference", "Роли колонок определены", details={"columns": len(roles)})

        self._begin("profiling", "Профилирование данных и пропусков")
        summary, column_profile, missingness = profile(lf.drop(row_id), roles, config.profiling, config.task, config.split.sample_column) if config.profiling.enabled else ({"rows": fingerprint["rows"]}, pl.DataFrame(), pl.DataFrame())
        self._end("profiling", "Профилирование завершено", details={"profiled_rows": summary.get("profiled_rows", 0)})

        self._begin("splitting", "Формирование или проверка выборок")
        sampled = lf
        sample_column = config.split.sample_column
        sample_counts = sampled.group_by(sample_column).len().collect()
        summary["samples"] = sample_counts.to_dicts()
        self._end("splitting", "Выборки готовы", details={row[sample_column]: row["len"] for row in sample_counts.iter_rows(named=True)})

        self._begin("rules_validation", "Проверка правил качества")
        rule_results, row_issues, quarantine_mask = evaluate_rules(sampled, config, row_id, sample_column)
        if config.duplicates.enabled and config.duplicates.action == "quarantine":
            subset = list(config.duplicates.key_columns) or [c for c in sampled.collect_schema() if c not in {sample_column, row_id}]
            duplicate_mask = pl.struct(subset).is_duplicated()
            duplicate_issues = sampled.filter(duplicate_mask).select(
                pl.col(row_id).cast(pl.String).alias("row_id"), pl.col(sample_column).cast(pl.String).alias("sample"),
                pl.lit(None, dtype=pl.String).alias("column"), pl.lit(None, dtype=pl.String).alias("original_value"),
                pl.lit(None, dtype=pl.String).alias("final_value"), pl.lit("duplicates").alias("rule"),
                pl.lit("duplicate row or business key").alias("reason"), pl.lit("error").alias("severity"),
                pl.lit("quarantined").alias("action"),
            ).collect(engine="streaming")
            if not duplicate_issues.is_empty():
                row_issues = pl.concat([row_issues, duplicate_issues], how="diagonal_relaxed")
                quarantine_mask |= duplicate_mask
        rule_issues = [{
            "check": "rule", "severity": row["severity"], "column": None, "sample": row["sample"],
            "row_id": None, "reason": f"{row['rule']}: {row['failed_rows']} violations ({row['failure_rate']:.4%})",
            "recommended_action": row["action"],
        } for row in rule_results if row["failed_rows"]]
        accepted = sampled.filter(~quarantine_mask)
        self._end("rules_validation", "Правила проверены", details={"violations": row_issues.height})

        self._begin("fit_train", "Расчёт преобразований на train", sample="train")
        train = accepted.filter(pl.col(sample_column) == train_name)
        if train.select(pl.len()).collect().item() == 0:
            raise ValueError(f"Reference sample is empty: {train_name}")
        self.state = fit(train, roles, config)
        self.state.input_schema = current_schema
        self.state.role_decisions = self.role_decisions
        self._end("fit_train", "Параметры train рассчитаны", sample=train_name)

        self._begin("transform", "Построение единого плана преобразований")
        prepared = transform(accepted, self.state, config)
        self.state.output_schema = {k: str(v) for k, v in prepared.collect_schema().items() if k != row_id}
        audit = transformation_issues(accepted, self.state, config, row_id, sample_column)
        if not audit.is_empty():
            row_issues = pl.concat([row_issues, audit], how="diagonal_relaxed")
        self._end("transform", "План преобразований готов", details={"audited_changes": audit.height})

        self._begin("quality_checks", "Проверки качества, утечек и дубликатов")
        quality_issues, quality_stats = check_quality(sampled, config, roles)
        unknown_rate = new_category_rate(sampled, self.state, config)
        issues = schema_issues + rule_issues + quality_issues
        self._end("quality_checks", "Проверки качества завершены", details=quality_stats)

        self._begin("drift_checks", "Проверка drift")
        drift, segment_drift, drift_issues = check_drift(sampled, roles, config.drift, config.task, sample_column)
        issues += drift_issues
        self._end("drift_checks", "Проверка drift завершена", details={"comparisons": drift.height})

        self._begin("quality_gates", "Применение quality gates")
        gates = evaluate_gates(config.quality_gates, summary["rows"], row_issues, issues, rule_results,
                               quality_stats["duplicate_rate"], unknown_rate)
        self._end("quality_gates", f"Quality gates: {gates['status']}")

        baseline_summary, baseline_frame = compare_baseline(summary, column_profile, baseline)
        return {
            "config": config, "source": sampled, "prepared": prepared, "row_id": row_id,
            "fingerprint": fingerprint, "summary": summary, "profile": column_profile,
            "missingness": missingness, "issues": issues, "row_issues": row_issues,
            "rules": rule_results, "drift": drift, "segment_drift": segment_drift,
            "gates": gates, "baseline_summary": baseline_summary, "baseline_frame": baseline_frame,
        }

    def prepare(self, data: pl.DataFrame | pl.LazyFrame | None = None) -> tuple[pl.LazyFrame, dict, pl.DataFrame, list[dict]]:
        if any(v is not None for v in (self.config.resources.cpu_threads, self.config.resources.threads, self.config.resources.ram_limit_gb, self.config.resources.memory_limit_gb)):
            raise ValueError("prepare возвращает ленивый план без контроля ресурсов; используйте run")
        result = self._process(data, load_baseline(self.config))
        return result["prepared"], result["summary"], result["profile"], result["issues"]

    def transform(self, data: pl.DataFrame | pl.LazyFrame) -> pl.LazyFrame:
        if self.state is None:
            raise RuntimeError("Pipeline is not fitted")
        lf = read_lazy(self.config.input, data)
        return transform(lf, self.state, self.config)

    def run(self, data: pl.DataFrame | pl.LazyFrame | None = None) -> RunResult:
        if self.config.resources.execution == "supervised":
            from .resources import supervised_run
            return supervised_run(self, data)
        return self._run_local(data)

    def _run_local(self, data=None) -> RunResult:
        started_at, started_clock, run_id = datetime.now(UTC), perf_counter(), uuid4().hex
        self._begin("initialization", "Инициализация запуска")
        baseline = load_baseline(self.config)
        output, stage = staging_directory(self.config.output)
        self._end("initialization", "Запуск инициализирован", details={"run_id": run_id})
        try:
            result = self._process(data, baseline)
            config, status = result["config"], result["gates"]["status"]
            files = []
            if status != "failed_quality_gate":
                self._begin("writing_data", "Запись подготовленных партиций")
                data_to_write = result["prepared"].drop(result["row_id"]) if result["row_id"] == "__tp_row_id" else result["prepared"]
                if config.input.layout != "files":
                    total = len(config.split.allowed_samples)
                    for current, sample_name in enumerate(config.split.allowed_samples, 1):
                        transform_stage = f"transform_{sample_name}"
                        self._begin(transform_stage, f"Преобразование и запись {sample_name}", sample=sample_name)
                        files += write_dataset(data_to_write.filter(pl.col(config.split.sample_column) == sample_name), stage, config.output)
                        self._end(transform_stage, f"Выборка {sample_name} записана", sample=sample_name, current=current, total=total)
                else:
                    files = write_dataset(data_to_write, stage, config.output)
                self._end("writing_data", "Партиции записаны", current=len(files), total=len(files))
            self._begin("quarantine", "Запись карантина")
            quarantine_files = write_quarantine(result["source"], result["row_issues"], result["row_id"], stage, config.output.compression)
            self._end("quarantine", "Карантин записан", current=len(quarantine_files), total=len(quarantine_files))
            self._begin("writing_state", "Сохранение состояния")
            self._save_state(stage / "state")
            self._end("writing_state", "Состояние сохранено")
            if config.reporting.enabled:
                self._begin("writing_reports", "Формирование отчётов")
                from .schema.review import role_proposals
                (stage / "reports").mkdir(exist_ok=True)
                (stage / "reports/role_proposals.json").write_text(json.dumps(role_proposals(self.role_decisions), ensure_ascii=False, indent=2), encoding="utf-8")
                save_reports(
                    stage / "reports", result["summary"], result["profile"], result["issues"],
                    missingness=result["missingness"], row_issues=result["row_issues"], rules=result["rules"],
                    drift=result["drift"], segment_drift=result["segment_drift"], quality_gates=result["gates"],
                    baseline=result["baseline_frame"], timeline=self.progress.rows(), write_html=config.reporting.html,
                )
                self._end("writing_reports", "Отчёты сформированы")
            self._begin("finalization", "Формирование manifest и фиксация результата")
            self._end("finalization", "Результат готов к фиксации")
            if config.reporting.enabled and config.progress.persist_events:
                pl.DataFrame(self.progress.rows(), infer_schema_length=None).write_parquet(stage / "reports/run_timeline.parquet")
            manifest = self._manifest(
                run_id, started_at, started_clock, files, quarantine_files, result,
            )
            (stage / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
            actual_output = output
            if status == "failed_quality_gate" and output.exists():
                actual_output = output.parent / f"{output.name}.failed-{run_id}"
            commit(actual_output, stage, config.output.overwrite if actual_output == output else False)
        except Exception as error:
            self.progress.fail(self._stage, error)
            try:
                reports = stage / "reports"
                reports.mkdir(parents=True, exist_ok=True)
                if self.config.progress.persist_events:
                    pl.DataFrame(self.progress.rows(), infer_schema_length=None).write_parquet(reports / "run_timeline.parquet")
                failure = {
                    "run_id": run_id, "status": "failed_runtime", "started_at": started_at.isoformat(),
                    "ended_at": datetime.now(UTC).isoformat(), "duration_seconds": perf_counter() - started_clock,
                    "failed_stage": self._stage, "error_type": type(error).__name__, "error": str(error),
                }
                (stage / "manifest.json").write_text(json.dumps(failure, ensure_ascii=False, indent=2), encoding="utf-8")
                self.last_failed_path = output.parent / f"{output.name}.failed-{run_id}"
                commit(self.last_failed_path, stage, False)
            except Exception:
                shutil.rmtree(stage, ignore_errors=True)
            raise
        return RunResult(
            actual_output, actual_output / "manifest.json", actual_output / "state/pipeline_state.json",
            manifest["accepted_rows"], len(files), manifest["status"], manifest["quarantined_rows"],
        )

    def _save_state(self, path: Path) -> None:
        path.mkdir(parents=True)
        self.state.save(path / "pipeline_state.json")
        for name, value in (("input_schema.json", self.state.input_schema), ("output_schema.json", self.state.output_schema), ("feature_roles.json", self.state.roles)):
            (path / name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
        numeric_rows = [{"column": c, **v, "bins": json.dumps(v["bins"])} for c, v in self.state.numeric.items()]
        category_rows = [{"column": c, **v, "known": json.dumps(v["known"], ensure_ascii=False), "mapping": json.dumps(v["mapping"], ensure_ascii=False), "frequencies": json.dumps(v["frequencies"], ensure_ascii=False)} for c, v in self.state.categorical.items()]
        pl.DataFrame(numeric_rows).write_parquet(path / "numeric_statistics.parquet")
        pl.DataFrame(category_rows).write_parquet(path / "category_mappings.parquet")
        transforms = [{"column": c, "role": role, "transformation": self._transformation(c, role)} for c, role in self.state.roles.items()]
        pl.DataFrame(transforms).write_parquet(path / "transformations.parquet")
        (path / "transform_log.json").write_text(json.dumps(transforms, ensure_ascii=False, indent=2), encoding="utf-8")

    def _manifest(self, run_id, started_at, started_clock, files, quarantine_files, result) -> dict:
        from .checks.drift import drift_columns
        drift_config = result["config"].drift
        selected = drift_columns(self.state.roles, drift_config) if drift_config.enabled else []
        skipped = [{"column": c, "reason": "disabled" if not drift_config.enabled else f"role:{r}" if r not in {"numeric", "categorical", "ordinal", "binary"} else "feature_selection"} for c, r in self.state.roles.items() if c not in selected]
        raw_config = json.dumps(asdict(self.config), ensure_ascii=False, sort_keys=True, default=str)
        quarantined = result["gates"]["metrics"]["quarantined_rows"]
        output_hash = sha256("".join(file["sha256"] for file in files).encode()).hexdigest()
        ended_at = datetime.now(UTC)
        return {
            "run_id": run_id, "status": result["gates"]["status"], "pipeline_version": self.state.version,
            "state_format_version": self.state.format_version, "started_at": started_at.isoformat(),
            "ended_at": ended_at.isoformat(), "duration_seconds": perf_counter() - started_clock,
            "python_version": platform.python_version(), "polars_version": pl.__version__,
            "config_sha256": sha256(raw_config.encode()).hexdigest(), "input_fingerprint": result["fingerprint"],
            "effective_config": json.loads(json.dumps(asdict(result["config"]), default=str)),
            "role_decisions": self.role_decisions,
            "temporal_check_scope": {"enabled": result["config"].leakage.enabled and result["config"].leakage.check_temporal_order, "pairs": list(result["config"].samples.temporal_pairs or tuple(zip(result["config"].samples.temporal_order, result["config"].samples.temporal_order[1:]))), "implicit_order": False},
            "numeric_parse_report": self.numeric_parse_report,
            "model_columns": [c for c, r in self.state.roles.items() if r in {"numeric", "categorical", "ordinal", "binary", "datetime", "text"}],
            "drift_coverage": {"enabled": drift_config.enabled, "selection": "explicit" if drift_config.columns else drift_config.selection, "selected_columns": selected, "skipped_columns": skipped, "completed_comparisons": result["drift"].height, "max_rows_per_sample": drift_config.max_rows_per_sample, "row_selection": "head_per_sample"},
            "output_fingerprint": {"sha256": output_hash, "files": len(files)},
            "rows": sum(file["rows"] for file in files), "accepted_rows": result["summary"]["rows"] - quarantined,
            "quarantined_rows": quarantined, "files": files, "quarantine_files": quarantine_files,
            "input_summary": result["summary"], "issues": {severity: sum(i["severity"] == severity for i in result["issues"]) for severity in ("critical", "error", "warning", "info")},
            "quality_gates": result["gates"], "baseline": result["baseline_summary"],
            "partition_columns": list(result["config"].output.partition_columns), "output_schema": self.state.output_schema,
            "stage_durations": self.progress.durations(),
        }

    def _transformation(self, column: str, role: str) -> str:
        if role == "numeric":
            return "numeric"
        if role in {"categorical", "ordinal", "binary"}:
            return self.state.categorical.get(column, {}).get("strategy", "native")
        if role == "datetime":
            return "datetime_components"
        if role == "text":
            return "text_statistics"
        return "passthrough"
