import html
import json
from pathlib import Path

import polars as pl


def save_reports(
    path: Path,
    summary: dict,
    profile: pl.DataFrame,
    issues: list[dict],
    *,
    missingness: pl.DataFrame | None = None,
    row_issues: pl.DataFrame | None = None,
    rules: list[dict] | None = None,
    drift: pl.DataFrame | None = None,
    segment_drift: pl.DataFrame | None = None,
    quality_gates: dict | None = None,
    baseline: pl.DataFrame | None = None,
    timeline: list[dict] | None = None,
    write_html: bool = True,
) -> None:
    path.mkdir(parents=True, exist_ok=True)
    _json(path / "summary.json", summary)
    _frame(profile).write_parquet(path / "profile.parquet")
    _frame(issues, _issue_schema()).write_parquet(path / "issues.parquet")
    _frame(missingness).write_parquet(path / "missingness.parquet")
    _frame(row_issues, _row_issue_schema()).write_parquet(path / "row_issues.parquet")
    _frame(rules).write_parquet(path / "rules.parquet")
    _frame(drift).write_parquet(path / "drift.parquet")
    _frame(segment_drift).write_parquet(path / "segment_drift.parquet")
    _frame(baseline).write_parquet(path / "baseline_comparison.parquet")
    _frame(timeline).write_parquet(path / "run_timeline.parquet")
    _json(path / "quality_gates.json", quality_gates or {})
    if write_html:
        (path / "report.html").write_text(_html(
            summary, issues, quality_gates or {}, rules or [], profile, missingness,
            row_issues, drift, segment_drift, baseline, timeline,
        ), encoding="utf-8")


def _frame(value, schema=None) -> pl.DataFrame:
    if isinstance(value, pl.DataFrame):
        return value
    if value:
        return pl.DataFrame(value, infer_schema_length=None)
    return pl.DataFrame(schema=schema or {})


def _json(path: Path, value) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str), encoding="utf-8")


def _issue_schema() -> dict:
    return {"check": pl.String, "severity": pl.String, "column": pl.String, "sample": pl.String,
            "row_id": pl.String, "reason": pl.String, "recommended_action": pl.String}


def _row_issue_schema() -> dict:
    return {"row_id": pl.String, "sample": pl.String, "column": pl.String, "original_value": pl.String,
            "final_value": pl.String, "rule": pl.String, "reason": pl.String, "severity": pl.String, "action": pl.String}


def _html(summary, issues, gates, rules, profile, missingness, row_issues, drift, segment_drift, baseline, timeline) -> str:
    status = gates.get("status", "unknown")
    color = "#2e7d32" if status == "passed" else "#ef6c00" if status == "passed_with_warnings" else "#c62828"
    gate_rows = "".join(f"<tr><td>{html.escape(str(g['name']))}</td><td>{g['value']}</td><td>{g['threshold']}</td><td>{'OK' if g['passed'] else 'FAIL'}</td></tr>" for g in gates.get("checks", []))
    return f"""<!doctype html><html lang='ru'><meta charset='utf-8'><title>Tabular Preprocessor</title>
<style>body{{font:14px system-ui;max-width:1200px;margin:40px auto;color:#27374f}}h1{{color:{color}}}table{{border-collapse:collapse;width:100%;margin:12px 0 28px}}td,th{{border:1px solid #d7dfeb;padding:7px;text-align:left}}th{{background:#edf2fa}}</style>
<h1>{html.escape(status)}</h1><p>Строк: <b>{summary.get('rows', 0)}</b> · Колонок: <b>{summary.get('columns', 0)}</b></p>
<h2>Quality gates</h2><table><tr><th>Проверка</th><th>Значение</th><th>Порог</th><th>Результат</th></tr>{gate_rows}</table>
<h2>Проблемы</h2>{_table(_frame(issues))}<h2>Нарушения строк</h2>{_table(_frame(row_issues))}
<h2>Правила</h2>{_table(_frame(rules))}<h2>Профиль колонок</h2>{_table(_frame(profile))}
<h2>Структура пропусков</h2>{_table(_frame(missingness))}<h2>Drift</h2>{_table(_frame(drift))}
<h2>Сегментные сравнения</h2>{_table(_frame(segment_drift))}<h2>Сравнение с baseline</h2>{_table(_frame(baseline))}
<h2>Ход выполнения</h2>{_table(_frame(timeline))}</html>"""


def _table(frame: pl.DataFrame, limit: int = 100) -> str:
    if frame.is_empty() or not frame.columns:
        return "<p>Нет данных</p>"
    columns = frame.columns
    head = "".join(f"<th>{html.escape(column)}</th>" for column in columns)
    rows = "".join("<tr>" + "".join(f"<td>{html.escape(str(value))}</td>" for value in row) + "</tr>" for row in frame.head(limit).iter_rows())
    return f"<table><tr>{head}</tr>{rows}</table>"
