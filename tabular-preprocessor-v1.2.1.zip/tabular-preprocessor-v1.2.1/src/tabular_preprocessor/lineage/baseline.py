import json
from pathlib import Path

import polars as pl

from ..config import ProjectConfig


def load_baseline(config: ProjectConfig) -> dict | None:
    raw = config.lineage.baseline_path
    if not raw and config.lineage.compare_previous:
        raw = config.output.path
    if not raw:
        return None
    root = Path(raw)
    manifest = root / "manifest.json"
    if not manifest.exists():
        return None
    manifest_data = json.loads(manifest.read_text(encoding="utf-8"))
    if manifest_data.get("status") not in {"passed", "passed_with_warnings", "success"}:
        return None
    result = {"path": str(root), "manifest": manifest_data}
    for name in ("profile", "missingness"):
        path = root / f"reports/{name}.parquet"
        result[name] = pl.read_parquet(path) if path.exists() else pl.DataFrame()
    state_schema = root / "state/input_schema.json"
    result["schema"] = json.loads(state_schema.read_text(encoding="utf-8")) if state_schema.exists() else {}
    return result


def compare_baseline(summary: dict, profile: pl.DataFrame, baseline: dict | None) -> tuple[dict, pl.DataFrame]:
    if not baseline:
        return {}, pl.DataFrame()
    old_summary = baseline["manifest"].get("input_summary", {})
    comparison = {
        "baseline_path": baseline["path"],
        "baseline_run_id": baseline["manifest"].get("run_id"),
        "rows_delta": summary.get("rows", 0) - old_summary.get("rows", 0),
        "columns_delta": summary.get("columns", 0) - old_summary.get("columns", 0),
    }
    old = baseline.get("profile", pl.DataFrame())
    if old.is_empty() or profile.is_empty() or "column" not in old:
        return comparison, pl.DataFrame()
    joined = profile.select("column", pl.col("null_fraction").alias("current_null_fraction")).join(
        old.select("column", pl.col("null_fraction").alias("baseline_null_fraction")), on="column", how="full", coalesce=True
    ).with_columns((pl.col("current_null_fraction") - pl.col("baseline_null_fraction")).alias("null_fraction_delta"))
    return comparison, joined
