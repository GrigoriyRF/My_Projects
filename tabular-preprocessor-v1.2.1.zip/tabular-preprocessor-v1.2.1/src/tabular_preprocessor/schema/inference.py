import re

import polars as pl

from ..config import Role, SchemaConfig, TaskConfig
from .numbers import parse_number, numeric_text


def infer_roles(lf: pl.LazyFrame, config: SchemaConfig, task: TaskConfig, decisions: list | None = None) -> dict[str, Role]:
    schema = lf.collect_schema()
    string_cols = [name for name, dtype in schema.items() if dtype == pl.String]
    string_stats: dict[str, tuple[int, float]] = {}
    if string_cols:
        expressions = [expr for c in string_cols for expr in (
            pl.col(c).n_unique().alias(f"{c}__n"),
            pl.col(c).str.len_chars().mean().fill_null(0).alias(f"{c}__len"),
            (parse_number(pl.col(c), config).count() / numeric_text(pl.col(c), config).count()).fill_nan(0).alias(f"{c}__numeric"),
            numeric_text(pl.col(c), config).str.contains(r"^[+-]?0\d").any().fill_null(False).alias(f"{c}__zeros"),
        )]
        row = lf.limit(config.inference_rows).select(expressions).collect()
        string_stats = {c: (row.item(0, f"{c}__n"), row.item(0, f"{c}__len")) for c in string_cols}

    roles: dict[str, Role] = {}
    for name, dtype in schema.items():
        if name in config.explicit_roles:
            roles[name] = config.explicit_roles[name]
        elif name == task.target:
            roles[name] = "target"
        elif name in task.id_columns:
            roles[name] = "id"
        elif name == task.date_column:
            roles[name] = "datetime"
        elif name in task.excluded_columns:
            roles[name] = "excluded"
        else:
            match = next((role for pattern, role in config.role_patterns.items() if re.search(pattern, name)), None)
            if match:
                roles[name] = match
            elif dtype.is_temporal():
                roles[name] = "datetime"
            elif dtype == pl.Boolean:
                roles[name] = "binary"
            elif dtype.is_numeric():
                roles[name] = "numeric"
            elif dtype == pl.String:
                unique, mean_length = string_stats[name]
                numeric_like = row.item(0, f"{name}__numeric") >= config.numeric_string_min_fraction
                numeric_like &= config.leading_zeros == "allow" or not row.item(0, f"{name}__zeros")
                high = config.max_categorical_cardinality is not None and unique > config.max_categorical_cardinality
                if numeric_like and config.numeric_strings != "keep":
                    roles[name] = "numeric" if config.numeric_strings == "convert" else "unknown"
                elif unique <= 2:
                    roles[name] = "binary"
                elif mean_length >= config.string_text_length:
                    roles[name] = "text"
                elif high:
                    if config.high_cardinality_action == "fail":
                        raise ValueError(f"Высокая кардинальность {name}: задайте explicit_roles или измените high_cardinality_action")
                    roles[name] = "excluded" if config.high_cardinality_action == "exclude" else "unknown"
                else:
                    roles[name] = "categorical"
            else:
                roles[name] = "unknown"
        if roles[name] == "unknown":
            if config.unknown_action == "fail":
                raise ValueError(f"Неоднозначная роль {name}: задайте schema.explicit_roles")
            if config.unknown_action == "exclude":
                roles[name] = "excluded"
        if decisions is not None:
            decisions.append({"column": name, "physical_type": str(dtype), "role": roles[name],
                              "source": "explicit" if name in config.explicit_roles else "task" if name in (*task.id_columns, *task.excluded_columns, task.target, task.date_column) else "pattern" if any(re.search(p, name) for p in config.role_patterns) else "inferred",
                              "numeric_fraction": row.item(0, f"{name}__numeric") if name in string_stats else None,
                              "n_unique_sampled": string_stats[name][0] if name in string_stats else None,
                              "leading_zeros_found": row.item(0, f"{name}__zeros") if name in string_stats else None,
                              "numeric_strings_policy": config.numeric_strings,
                              "high_cardinality_policy": config.high_cardinality_action,
                              "unknown_policy": config.unknown_action,
                              "sample_limit": config.inference_rows,
                              "requires_review": roles[name] == "unknown"})
    return roles
