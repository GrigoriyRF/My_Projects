import re
import polars as pl


def numeric_text(expr, config):
    x = expr.cast(pl.String).str.strip_chars()
    return pl.when(x.is_in(config.numeric_null_values)).then(None).otherwise(x)


def parse_number(expr, config):
    x = numeric_text(expr, config)
    d = re.escape(config.decimal_separator)
    t = re.escape(config.thousands_separator) if config.thousands_separator else None
    integer = rf"(?:\d+|\d{{1,3}}(?:{t}\d{{3}})+)" if t else r"\d+"
    valid = x.str.contains(rf"^[+-]?(?:{integer}(?:{d}\d*)?|{d}\d+)(?:[eE][+-]?\d+)?$")
    if t:
        x = x.str.replace_all(config.thousands_separator, "", literal=True)
    x = x.str.replace_all(config.decimal_separator, ".", literal=True)
    number = pl.when(valid).then(x.cast(pl.Float64, strict=False)).otherwise(None)
    return pl.when(number.is_finite()).then(number).otherwise(None)


def normalize_numbers(lf, roles, config):
    schema = lf.collect_schema()
    columns = [c for c, role in roles.items() if role == "numeric" and schema.get(c) == pl.String]
    if config.numeric_parse_errors == "fail" and columns:
        counts = lf.select([(numeric_text(pl.col(c), config).is_not_null() & parse_number(pl.col(c), config).is_null()).sum().alias(c) for c in columns]).collect().row(0, named=True)
        invalid = {c: n for c, n in counts.items() if n}
        if invalid:
            raise ValueError(f"Не удалось преобразовать строки в числа: {invalid}; исправьте формат либо явно разрешите numeric_parse_errors='null'")
    return lf.with_columns([parse_number(pl.col(c), config).alias(c) for c in columns])
