def role_proposals(decisions):
    result = []
    for d in decisions:
        if d["role"] != "unknown":
            continue
        numeric = d.get("numeric_fraction") == 1 and not d.get("leading_zeros_found")
        result.append({"column": d["column"], "candidate_roles": ["numeric", "categorical", "id"] if numeric else ["categorical", "text", "id"],
                       "reason": "Все непустые значения среза читаются как числа; смысл не определён" if numeric else "Строковая колонка требует определения смысла",
                       "numeric_fraction": d.get("numeric_fraction"), "unique_in_sample": d.get("n_unique_sampled"),
                       "action": "Укажите schema.explicit_roles[column]; число может быть кодом или ID"})
    return result
