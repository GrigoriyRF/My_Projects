"""Isolated run; parent owns publication, deadline and sampled RSS budget."""
import json
import multiprocessing as mp
import os
import shutil
import tempfile
import threading
from dataclasses import asdict, replace
from pathlib import Path
from queue import Empty
from time import monotonic
from uuid import uuid4

import psutil

from .io.writer import commit
from .transformations.state import PipelineState

_spawn_lock = threading.Lock()


def _rss(pid):
    parent = psutil.Process(pid)
    return sum(p.memory_info().rss for p in [parent, *parent.children(recursive=True)] if p.is_running())


def _worker(config, data, queue):
    from .pipeline import Pipeline
    try:
        import polars as pl
        expected = config.resources.cpu_threads or config.resources.threads
        if expected and pl.thread_pool_size() != expected:
            raise RuntimeError(f"Не удалось применить CPU-потоки: {pl.thread_pool_size()} вместо {expected}")
        pipeline = Pipeline(config, progress_callback=lambda e: queue.put(("event", e)))
        pipeline.progress.enabled = True
        result = pipeline._run_local(data)
        queue.put(("result", result))
    except BaseException as error:
        queue.put(("error", (type(error).__name__, str(error), getattr(locals().get("pipeline"), "_stage", "initialization"))))


def supervised_run(pipeline, data):
    cfg, budget = pipeline.config, pipeline.config.resources
    output = Path(cfg.output.path).resolve()
    if output.exists() and not cfg.output.overwrite:
        raise FileExistsError(f"Output already exists: {output}")
    cpu = budget.cpu_threads or budget.threads
    ram = budget.ram_limit_gb or budget.memory_limit_gb
    try:
        _rss(os.getpid())
        rss_available = True
    except (psutil.Error, OSError):
        rss_available = False
        if ram:
            raise ValueError("RSS процессов недоступен в этой среде: RAM-бюджет нельзя обеспечить")
    output.parent.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix=f".{output.name}.worker-", dir=output.parent))
    lineage = replace(cfg.lineage, baseline_path=cfg.lineage.baseline_path or (str(output) if cfg.lineage.compare_previous else None))
    worker_config = replace(cfg, lineage=lineage, output=replace(cfg.output, path=str(work / "result"), overwrite=False))
    context = mp.get_context("spawn")
    queue = context.Queue()
    process = context.Process(target=_worker, args=(worker_config, data, queue))
    started, peak, result = monotonic(), 0, None
    active_stages, stage_memory = [], {}
    env = {"POLARS_MAX_THREADS": str(cpu)} if cpu else {}
    if cpu:
        env.update({name: str(cpu) for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS")})
    try:
        # Inherit limits before the child imports Polars. Restore the parent environment.
        with _spawn_lock:
            previous = {name: os.environ.get(name) for name in env}
            try:
                os.environ.update(env)
                process.start()
            finally:
                for name, value in previous.items():
                    if value is None:
                        os.environ.pop(name, None)
                    else:
                        os.environ[name] = value
        while result is None:
            if budget.max_runtime_hours and monotonic() - started >= budget.max_runtime_hours * 3600:
                raise TimeoutError("Превышено resources.max_runtime_hours; результат не опубликован")
            try:
                rss = _rss(process.pid) if rss_available else 0
                peak = max(peak, rss)
                if rss_available:
                    for stage_name in active_stages or ["initialization"]:
                        entry = stage_memory.setdefault(stage_name, {"peak_rss_bytes": 0, "measurements": 0})
                        entry["peak_rss_bytes"] = max(entry["peak_rss_bytes"], rss)
                        entry["measurements"] += 1
                if ram and rss > ram * 1024**3:
                    raise MemoryError("Превышен контролируемый RSS-бюджет resources.ram_limit_gb; результат не опубликован")
            except psutil.NoSuchProcess:
                pass
            try:
                kind, payload = queue.get(timeout=budget.poll_interval_seconds)
            except Empty:
                if not process.is_alive():
                    raise RuntimeError(f"Рабочий процесс завершился без результата: exitcode={process.exitcode}")
                continue
            if kind == "event":
                if payload.status == "started":
                    active_stages.append(payload.stage)
                elif payload.status in {"completed", "failed"} and payload.stage in active_stages:
                    active_stages.remove(payload.stage)
                pipeline.progress.events.append(payload)
                pipeline._stage = payload.stage
                if pipeline.progress.enabled and pipeline.progress.callback:
                    try:
                        pipeline.progress.callback(payload)
                    except Exception:
                        pass
            elif kind == "error":
                name, message, pipeline._stage = payload
                exception = {"ValueError": ValueError, "FileNotFoundError": FileNotFoundError, "MemoryError": MemoryError}.get(name, RuntimeError)
                raise exception(message)
            else:
                result = payload
        process.join(timeout=5)
        if process.is_alive():
            raise RuntimeError("Рабочий процесс не завершился после результата")
        if budget.max_runtime_hours and monotonic() - started >= budget.max_runtime_hours * 3600:
            raise TimeoutError("Лимит времени истёк до публикации")
        manifest = json.loads(result.manifest_path.read_text())
        manifest["effective_config"]["output"] = asdict(cfg.output)
        manifest["effective_config"]["lineage"] = asdict(cfg.lineage)
        from hashlib import sha256
        manifest["config_sha256"] = sha256(json.dumps(asdict(cfg), ensure_ascii=False, sort_keys=True, default=str).encode()).hexdigest()
        manifest["resource_usage"] = {"peak_sampled_rss_bytes": peak if rss_available else None, "cpu_threads_requested": cpu, "ram_mode": "sampled_rss_watchdog" if rss_available else "unavailable", "poll_interval_seconds": budget.poll_interval_seconds, "max_runtime_hours": budget.max_runtime_hours, "gpu_used": False}
        manifest["resource_usage"]["stage_memory"] = stage_memory
        manifest["resource_usage"]["stage_attribution"] = "parent_received_events; sampled, overlapping stages share measurements"
        result.manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2, default=str))
        target = output if result.status != "failed_quality_gate" or not output.exists() else output.parent / f"{output.name}.failed-{uuid4().hex}"
        pipeline.state = PipelineState.load(result.state_path)
        commit(target, result.output_path, cfg.output.overwrite if target == output else False)
        shutil.rmtree(work, ignore_errors=True)
        return replace(result, output_path=target, manifest_path=target / "manifest.json", state_path=target / "state/pipeline_state.json")
    except BaseException as error:
        if process.pid and process.is_alive():
            process.terminate()
            process.join(timeout=2)
            if process.is_alive():
                process.kill()
                process.join(timeout=2)
        failed = output.parent / f"{output.name}.failed-{uuid4().hex}"
        failed.mkdir()
        (failed / "resource_usage.json").write_text(json.dumps({"stage_memory": stage_memory, "peak_rss_bytes": peak if rss_available else None}, indent=2))
        for reports in work.glob("*/reports"):
            shutil.copytree(reports, failed / "reports", dirs_exist_ok=True)
        (failed / "manifest.json").write_text(json.dumps({"status": "failed_resource" if isinstance(error, (TimeoutError, MemoryError)) else "failed_runtime", "failed_stage": pipeline._stage, "error": str(error), "published": False, "peak_sampled_rss_bytes": peak if rss_available else None}, ensure_ascii=False, indent=2))
        pipeline.last_failed_path = failed
        # Only this run's validated temporary directory is removed.
        shutil.rmtree(work)
        raise
    finally:
        queue.close()
