from dataclasses import fields, is_dataclass
from types import UnionType
from typing import Any, Literal, Union, get_args, get_origin, get_type_hints


def validate_types(value, hint, path="config"):
    origin, args = get_origin(hint), get_args(hint)
    if hint is Any:
        return
    if origin in (Union, UnionType):
        for option in args:
            try:
                validate_types(value, option, path)
                return
            except TypeError:
                pass
    elif origin is Literal:
        if value in args:
            return
    elif origin is tuple and isinstance(value, tuple):
        if len(args) == 2 and args[1] is Ellipsis:
            for i, item in enumerate(value):
                validate_types(item, args[0], f"{path}[{i}]")
            return
        if len(value) == len(args):
            for i, (item, subtype) in enumerate(zip(value, args)):
                validate_types(item, subtype, f"{path}[{i}]")
            return
    elif origin is dict and isinstance(value, dict):
        for key, item in value.items():
            validate_types(key, args[0], f"{path}.key")
            validate_types(item, args[1], f"{path}[{key!r}]")
        return
    elif isinstance(hint, type) and isinstance(value, hint):
        if hint in (int, float) and isinstance(value, bool):
            pass
        else:
            if is_dataclass(value):
                hints = get_type_hints(type(value))
                for f in fields(value):
                    validate_types(getattr(value, f.name), hints[f.name], f"{path}.{f.name}")
            return
    elif hint is float and type(value) is int:
        return
    raise TypeError(f"{path}: ожидается {hint}, получен {type(value).__name__}. Проверьте лишнюю запятую, вложенные кортежи и именованные аргументы.")
