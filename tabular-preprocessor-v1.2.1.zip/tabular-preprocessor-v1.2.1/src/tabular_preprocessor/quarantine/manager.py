from pathlib import Path

import polars as pl


def write_quarantine(
    lf: pl.LazyFrame,
    row_issues: pl.DataFrame,
    row_id: str,
    root: Path,
    compression: str,
) -> list[dict]:
    quarantined = row_issues.filter(pl.col("action") == "quarantined")
    if quarantined.is_empty():
        return []
    outputs = []
    groups = {
        "invalid_schema": quarantined.filter(pl.col("rule").str.starts_with("schema.")),
        "duplicates": quarantined.filter(pl.col("rule") == "duplicates"),
        "invalid_rules": quarantined.filter(~pl.col("rule").str.starts_with("schema.") & (pl.col("rule") != "duplicates")),
    }
    for name, issues in groups.items():
        ids = issues["row_id"].unique().to_list()
        if not ids:
            continue
        path = root / "quarantine" / name / "part-00000.parquet"
        path.parent.mkdir(parents=True, exist_ok=True)
        frame = lf.filter(pl.col(row_id).cast(pl.String).is_in(ids))
        rows = frame.select(pl.len()).collect().item()
        frame.sink_parquet(path, compression=compression, mkdir=True)
        outputs.append({"reason": name, "path": str(path.relative_to(root)), "rows": rows})
    return outputs
