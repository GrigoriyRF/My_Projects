from .manager import write_quarantine

__all__ = ["write_quarantine"]
