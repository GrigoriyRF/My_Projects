import json
from dataclasses import replace

import polars as pl
import pytest

from tabular_preprocessor import Pipeline
from tabular_preprocessor.config import (
    ProjectConfig, InputConfig, TaskConfig, OutputConfig, SchemaConfig,
    ResourceConfig, SplitConfig, IdentityConfig, SampleConfig, DriftConfig,
    QualityGateConfig, NumericConfig,
)
from tabular_preprocessor.schema.inference import infer_roles
from tabular_preprocessor.schema.numbers import normalize_numbers
from tabular_preprocessor.checks.drift import drift_columns


def config(tmp_path, **kwargs):
    return ProjectConfig(input=InputConfig(paths=("unused",)), task=TaskConfig(),
                         output=OutputConfig(path=str(tmp_path / "out")), **kwargs)


def test_localized_numbers_and_leading_zeros():
    s = SchemaConfig(numeric_strings="convert", decimal_separator=",", thousands_separator=" ")
    lf = pl.DataFrame({"x": ["1 234,5", "2,5", ""], "code": ["001", "002", "003"]}).lazy()
    roles = infer_roles(lf, s, TaskConfig())
    assert roles["x"] == "numeric" and roles["code"] != "numeric"
    assert normalize_numbers(lf, roles, s).collect()["x"].to_list() == [1234.5, 2.5, None]


def test_invalid_number_is_not_silently_imputed():
    lf = pl.DataFrame({"x": ["1 23", "5"]}).lazy()
    with pytest.raises(ValueError, match="преобразовать"):
        normalize_numbers(lf, {"x": "numeric"}, SchemaConfig(thousands_separator=" "))
    out = normalize_numbers(lf, {"x": "numeric"}, SchemaConfig(numeric_parse_errors="null")).collect()
    assert out["x"].to_list() == [None, 5.0]


def test_roles_only_train_and_state_settings(tmp_path):
    cfg = config(tmp_path, schema=SchemaConfig(numeric_strings="convert", numeric_parse_errors="null"),
                 split=SplitConfig(method="existing", allowed_samples=("train", "valid")))
    data = pl.DataFrame({"sample": ["valid", "train", "train"], "x": ["bad", "1", "3"]})
    pipeline = Pipeline(cfg)
    pipeline.prepare(data)
    assert pipeline.state.roles["x"] == "numeric"
    assert pipeline.state.numeric["x"]["fill"] == 2
    path = tmp_path / "state.json"
    pipeline.state.save(path)
    changed = replace(cfg, schema=SchemaConfig(numeric_parse_errors="fail"), numeric=NumericConfig(log1p=("x",)))
    restored = Pipeline.from_state(changed, path)
    assert restored.transform(pl.DataFrame({"x": ["bad", "3"]})).collect()["x"].to_list() == [2.0, 3.0]


def test_unknown_fail(tmp_path):
    cfg = config(tmp_path, schema=SchemaConfig(unknown_action="fail"))
    with pytest.raises(ValueError, match="Неоднозначная"):
        Pipeline(cfg).prepare(pl.DataFrame({"x": ["1", "2", "3"]}))


def test_drift_selection():
    roles = {f"x{i}": "numeric" for i in range(10)} | {"code": "id"}
    cfg = DriftConfig(selection="random", max_features=3)
    assert drift_columns(roles, cfg) == drift_columns(dict(reversed(list(roles.items()))), cfg)
    assert len(drift_columns(roles, replace(cfg, selection="all"))) == 10
    assert drift_columns(roles, replace(cfg, columns=("x1", "x2"), max_features=1)) == ["x1", "x2"]
    with pytest.raises(ValueError):
        drift_columns(roles, DriftConfig(columns=("code",)))


@pytest.mark.parametrize("resources", [ResourceConfig(gpu_enabled=True), ResourceConfig(cpu_threads=0), ResourceConfig(execution="in_process"), ResourceConfig(cpu_threads=1.5)])
def test_bad_resources_fail_before_read(tmp_path, resources):
    with pytest.raises((ValueError, TypeError)):
        Pipeline(config(tmp_path, resources=resources))


def test_timeout_does_not_publish(tmp_path):
    cfg = config(tmp_path, resources=ResourceConfig(max_runtime_hours=1e-10))
    pipeline = Pipeline(cfg)
    with pytest.raises(TimeoutError):
        pipeline.run(pl.DataFrame({"x": [1, 2, 3]}))
    assert not (tmp_path / "out").exists()
    assert json.loads((pipeline.last_failed_path / "manifest.json").read_text())["status"] == "failed_resource"


def test_ram_does_not_replace_previous_output(tmp_path, monkeypatch):
    from tabular_preprocessor import resources
    monkeypatch.setattr(resources, "_rss", lambda pid: 1024**3)
    output = tmp_path / "out"
    output.mkdir()
    (output / "marker").write_text("previous")
    cfg = config(tmp_path, resources=ResourceConfig(ram_limit_gb=1e-9, poll_interval_seconds=0.01))
    cfg = replace(cfg, output=replace(cfg.output, overwrite=True))
    with pytest.raises(MemoryError):
        Pipeline(cfg).run(pl.DataFrame({"x": [1, 2, 3]}))
    assert (output / "marker").read_text() == "previous"


def test_cpu_and_coverage_in_manifest(tmp_path):
    cfg = config(tmp_path, resources=ResourceConfig(cpu_threads=2), drift=DriftConfig(enabled=True, selection="all"))
    p = Pipeline(cfg)
    result = p.run(pl.DataFrame({"x": [1, 2, 3]}))
    m = json.loads(result.manifest_path.read_text())
    assert m["resource_usage"]["cpu_threads_requested"] == 2
    assert m["drift_coverage"]["selected_columns"] == ["x"]
    assert m["effective_config"]["output"]["path"] == cfg.output.path
    assert p.state is not None


def test_composite_entity_overlap_policy(tmp_path):
    data = pl.DataFrame({"sample": ["train", "valid", "train", "valid"], "a": [1, 1, 2, 2], "b": [1, 2, 1, 2], "x": [5, 6, 7, 8]})
    cfg = config(tmp_path, split=SplitConfig(method="existing", allowed_samples=("train", "valid")),
                 identity=IdentityConfig(entity_key=("a", "b")), samples=SampleConfig(allow_entity_overlap=False))
    issues = Pipeline(cfg).prepare(data)[3]
    assert not any(i["check"] == "sample_overlap" for i in issues)
    issues = Pipeline(cfg).prepare(data.with_columns(pl.lit(1).alias("b")))[3]
    assert any(i["check"] == "sample_overlap" for i in issues)


def test_row_key_gate(tmp_path):
    cfg = config(tmp_path, identity=IdentityConfig(row_key=("id",)), quality_gates=QualityGateConfig(max_issue_counts={"row_key": 0}))
    result = Pipeline(cfg).run(pl.DataFrame({"id": [1, 1], "x": [3, 4]}))
    assert result.status == "failed_quality_gate"
    assert not (result.output_path / "data").exists()


def test_unavailable_rss_is_rejected_before_io(tmp_path, monkeypatch):
    from tabular_preprocessor import resources
    def unavailable(pid):
        raise resources.psutil.NoSuchProcess(pid)
    monkeypatch.setattr(resources, "_rss", unavailable)
    with pytest.raises(ValueError, match="RSS"):
        Pipeline(config(tmp_path, resources=ResourceConfig(ram_limit_gb=1))).run()
    assert not list(tmp_path.iterdir())


def test_baseline_numeric_strings_and_csv_ipc(tmp_path):
    cfg = config(tmp_path, schema=SchemaConfig(numeric_strings="convert", policy="exact"))
    frame = pl.DataFrame({"x": ["1", "2", "3"]})
    Pipeline(cfg).run(frame)
    cfg = replace(cfg, output=replace(cfg.output, overwrite=True))
    assert Pipeline(cfg).run(frame).status != "failed_quality_gate"
    for fmt in ("csv", "ipc"):
        path = tmp_path / f"input.{fmt}"
        getattr(frame, f"write_{fmt}")(path)
        other = replace(cfg, input=InputConfig(paths=(str(path),), format=fmt), schema=SchemaConfig())
        assert Pipeline(other).run().rows == 3


def test_unknown_gate_and_parse_report(tmp_path):
    cfg = config(tmp_path, quality_gates=QualityGateConfig(max_issue_counts={"ambiguous_role": 0}))
    result = Pipeline(cfg).run(pl.DataFrame({"x": ["1", "2", "3"]}))
    assert result.status == "failed_quality_gate"
    cfg = replace(cfg, output=replace(cfg.output, overwrite=True), schema=SchemaConfig(explicit_roles={"x": "numeric"}, numeric_parse_errors="null"))
    result = Pipeline(cfg).run(pl.DataFrame({"x": ["bad", "2", "3"]}))
    report = json.loads(result.manifest_path.read_text())["numeric_parse_report"]
    assert sum(row["invalid_values"] for row in report) == 1


def test_template_validates():
    from pathlib import Path
    from tabular_preprocessor.cli import load_config
    load_config(str(Path(__file__).parents[1] / "examples/config_universal.py")).validate()


def test_commit_refuses_overwrite(tmp_path):
    from tabular_preprocessor.io.writer import commit
    output, staging = tmp_path / "old", tmp_path / "new"
    output.mkdir()
    staging.mkdir()
    with pytest.raises(FileExistsError):
        commit(output, staging, False)
    assert output.exists() and staging.exists()
