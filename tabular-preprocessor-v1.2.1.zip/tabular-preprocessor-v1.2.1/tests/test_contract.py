import polars as pl
from tabular_preprocessor.config import SchemaConfig, TaskConfig, ProfilingConfig, QualityGateConfig
from tabular_preprocessor.schema.inference import infer_roles
from tabular_preprocessor.profiling.dataset import profile
from tabular_preprocessor.checks.gates import evaluate_gates


def test_numeric_strings_are_not_excluded():
    lf = pl.DataFrame({"amount": [str(i) for i in range(1500)]}).lazy()
    assert infer_roles(lf, SchemaConfig(), TaskConfig())["amount"] == "unknown"
    assert infer_roles(lf, SchemaConfig(numeric_strings="convert"), TaskConfig())["amount"] == "numeric"
    assert infer_roles(lf, SchemaConfig(explicit_roles={"amount": "categorical"}), TaskConfig())["amount"] == "categorical"


def test_full_target_summary_with_partial_profile():
    lf = pl.DataFrame({"target": [0, 0, 1, 1]}).lazy()
    summary, _, _ = profile(lf, {"target": "target"}, ProfilingConfig(sample_rows=2), TaskConfig(target="target"))
    assert sum(r["count"] for r in summary["target_distribution"]) == 4
    assert summary["profile_scope"] == "head"


def test_independent_overlap_gate():
    issues = [{"check": "sample_overlap", "severity": "critical"}]
    result = evaluate_gates(QualityGateConfig(max_sample_overlap_issues=0), 10, pl.DataFrame(), issues, [], 0, 0)
    assert result["status"] == "failed_quality_gate"
    assert next(c for c in result["checks"] if c["name"] == "schema_errors")["passed"]
    result = evaluate_gates(QualityGateConfig(), 10, pl.DataFrame(), issues, [], 0, 0)
    assert result["status"] == "passed_with_warnings"
