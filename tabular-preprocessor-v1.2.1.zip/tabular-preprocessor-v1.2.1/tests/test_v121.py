from dataclasses import replace
import json
import hashlib
import polars as pl
import pytest
from tabular_preprocessor import Pipeline
from tabular_preprocessor.config import *


def cfg(tmp_path, **kwargs):
    return ProjectConfig(input=InputConfig(paths=("unused",)), task=TaskConfig(date_column="date"),
                         output=OutputConfig(path=str(tmp_path / "out")),
                         split=SplitConfig(method="existing", allowed_samples=("train", "valid", "oot")), **kwargs)


def frame():
    return pl.DataFrame({"sample": ["train", "train", "valid", "oot"],
                         "date": ["2024-02-01", "2024-03-01", "2024-01-01", "2024-04-01"], "x": [1, 2, 3, 4]})


def test_temporal_only_explicit(tmp_path):
    config = cfg(tmp_path)
    assert not any(i["check"] == "temporal_overlap" for i in Pipeline(config).prepare(frame())[3])
    config = replace(config, samples=SampleConfig(temporal_pairs=(("train", "oot"), ("valid", "oot"))))
    assert not any(i["check"] == "temporal_overlap" for i in Pipeline(config).prepare(frame())[3])
    config = replace(config, samples=SampleConfig(temporal_pairs=(("train", "valid"),)))
    assert sum(i["check"] == "temporal_overlap" for i in Pipeline(config).prepare(frame())[3]) == 1


@pytest.mark.parametrize("task", [TaskConfig(target=("y",)), TaskConfig(id_columns=(("id",),)), TaskConfig(date_column=("date",)), TaskConfig(("y",), (("id",),), ("date",))])
def test_early_tuple_error(tmp_path, task):
    with pytest.raises(TypeError, match="config.task"):
        Pipeline(replace(cfg(tmp_path), task=task))


def test_bad_required_columns(tmp_path):
    with pytest.raises(TypeError, match="required_columns"):
        Pipeline(cfg(tmp_path, schema=SchemaConfig(required_columns=("x", ("id",)))))


def test_bad_temporal_pairs(tmp_path):
    with pytest.raises(ValueError, match="temporal_pairs"):
        Pipeline(cfg(tmp_path, samples=SampleConfig(temporal_pairs=(("train", "absent"),))))


def test_category_fit_aggregates(tmp_path):
    config = cfg(tmp_path, missing=MissingConfig(categorical="most_frequent"))
    f = frame().with_columns(pl.Series("cat", [" A ", None, "new", "new"]))
    p = Pipeline(config)
    p.prepare(f)
    assert p.state.categorical["cat"]["fill"] == "a"
    assert p.state.categorical["cat"]["frequencies"] == {"a": 1.0}


def test_stage_memory_and_role_report(tmp_path, monkeypatch):
    from tabular_preprocessor import resources
    monkeypatch.setattr(resources, "_rss", lambda pid: 123456)
    result = Pipeline(cfg(tmp_path, progress=ProgressConfig(enabled=False))).run(frame().with_columns(pl.Series("amount", ["1", "2", "3", "4"])))
    manifest = json.loads(result.manifest_path.read_text())
    assert manifest["resource_usage"]["stage_memory"]["profiling"]["peak_rss_bytes"] == 123456
    proposals = json.loads((result.output_path / "reports/role_proposals.json").read_text())
    assert proposals[0]["column"] == "amount"
    assert "id" in proposals[0]["candidate_roles"]


def test_streaming_file_hash(tmp_path, monkeypatch):
    from pathlib import Path
    from tabular_preprocessor.io.writer import file_sha256
    path = tmp_path / "bytes"
    path.write_bytes(b"abc" * 1000)
    def forbidden(*args):
        raise AssertionError("whole-file read")
    monkeypatch.setattr(Path, "read_bytes", forbidden)
    assert file_sha256(path) == hashlib.sha256(b"abc" * 1000).hexdigest()
