"""Универсальный шаблон 1.2.1. Измените пути и ответы под свои данные.

Запуск из Jupyter: result = Pipeline(CONFIG).run()
Из .py-файла запуск помещайте внутрь if __name__ == '__main__'.
Никакие имена колонок или правила предметной области не зашиты в ядро.
"""
from tabular_preprocessor.config import (
    ProjectConfig, InputConfig, OutputConfig, TaskConfig, IdentityConfig,
    SampleConfig, SchemaConfig, SplitConfig, RuleConfig, ProfilingConfig,
    MissingConfig, NumericConfig, CategoricalConfig, DatetimeConfig, TextConfig,
    LeakageConfig, DuplicateConfig, DriftConfig, QualityGateConfig,
    QuarantineConfig, LineageConfig, ProgressConfig, ResourceConfig, ReportingConfig,
)

CONFIG = ProjectConfig(
    input=InputConfig(
        paths=("/data/input",),             # Где лежат файлы? Замените путь.
        format="parquet",                   # Формат: parquet, csv или ipc?
        layout="files",                     # files, sample_directories или sample_paths?
        samples=(),                         # Имена папок готовых выборок, если sample_directories.
        sample_paths={},                    # Или явный словарь: имя выборки -> кортеж путей.
        sample_column="sample",             # Как называется колонка выборки?
        file_pattern="**/*.parquet",         # Какие файлы искать? Для CSV/IPC измените расширение.
        columns=None,                       # Какие колонки читать? None — все.
        row_index=None,                     # Есть готовый уникальный технический индекс строки?
        csv_separator=",",                  # Разделитель полей CSV, не десятичный разделитель.
        checksum=True,                      # Считать контрольные суммы файлов?
    ),
    task=TaskConfig(
        task_type="unsupervised",           # binary / multiclass / regression / unsupervised.
        target=None,                        # Как называется таргет? Обязателен для supervised-задач.
        observation_unit=None,              # Что означает строка? Свободное описание для manifest.
        date_column=None,                   # Дата наблюдения для временных проверок.
        prediction_time_column=None,        # Момент прогноза: колонка фиксируется и проверяется на наличие.
        available_after_prediction=(),      # Какие признаки заведомо известны только после прогноза?
        id_columns=(),                      # Старый интерфейс ID; предпочтительнее identity ниже.
        excluded_columns=(),                # Какие колонки не использовать как признаки?
    ),
    identity=IdentityConfig(
        row_key=(),                         # Какие колонки ВМЕСТЕ уникально определяют строку?
        business_key=(),                    # Составной бизнес-ключ (семантика, не автоматическая уникальность).
        entity_key=(),                      # Как определить сущность: клиента, объект и т. п.?
        group_key=(),                       # Какие колонки ВМЕСТЕ задают группу для разбиения?
        technical_columns=(),              # Какие поля служебные и не являются признаками?
    ),
    samples=SampleConfig(
        fit_sample=None,                    # На какой выборке обучать роли и преобразования?
        # None: train, если она объявлена; иначе первая из split.allowed_samples.
        purposes={},                        # Назначение каждой выборки: свободный текст для manifest.
        temporal_order=(),                  # Какие выборки идут строго последовательно? Пусто — порядок не задан.
        temporal_pairs=(),                  # Какие пары сравнивать: (("train", "oot"),)? Не совмещать с temporal_order.
        allow_entity_overlap=True,          # Допустима одна сущность в разных выборках?
        allow_group_overlap=False,          # Допустима одна группа в разных выборках?
    ),
    split=SplitConfig(
        method="none",                      # none/existing/random/stratified/group/temporal/group_temporal.
        allowed_samples=("train",),         # Какие выборки ожидаются/создаются?
        sample_column="sample",             # Для layout=files: колонка готового разбиения.
        fractions=(1.0,),                   # Доли для random/stratified/group; сумма = 1.
        group_columns=(),                   # Пусто — взять identity.group_key; составной ключ.
        group_column=None,                  # Старое имя для одиночной колонки группировки.
        date_column=None,                   # Дата разбиения; None — task.date_column.
        boundaries=(),                      # Границы периодов YYYY-MM-DD; число выборок минус 1.
        seed=42,                            # Seed воспроизводимого разбиения.
    ),
    schema=SchemaConfig(
        explicit_roles={},                 # Явные роли: numeric/categorical/ordinal/binary/datetime/
        # text/id/target/technical/excluded/unknown. Приоритет над автоопределением.
        role_patterns={},                  # Регулярное выражение имени -> роль.
        required_columns=(),               # Какие колонки обязательно должны присутствовать?
        nullable={},                       # Колонка -> допускаются ли пропуски?
        ranges={},                         # Колонка -> (минимум, максимум), None — без границы.
        allowed_values={},                 # Колонка -> кортеж допустимых значений.
        casts={},                          # Явные физические casts; ошибки старого cast дают null.
        policy="permissive",                # exact/backward/permissive — политика изменения схемы.
        expected_schema={},                # Ожидаемые физические типы; пусто — baseline, если задан.
        preserve_column_order=False,       # Проверять порядок колонок?
        numeric_strings="suggest",          # suggest: unknown; convert: числа; keep: обычные строки.
        numeric_string_min_fraction=1.0,    # Какая доля распознаваемых чисел нужна для предложения?
        inference_rows=100_000,             # Сколько первых строк FIT-выборки использовать для ролей?
        decimal_separator=".",              # Десятичный разделитель: точка или запятая?
        thousands_separator=None,          # Разделитель тысяч: None, пробел, запятая и т. п.
        numeric_null_values=("",),          # Какие строки считать пропусками при разборе чисел?
        leading_zeros="preserve",            # preserve: не считать 00123 числом автоматически; allow — разрешить.
        numeric_parse_errors="fail",         # Ошибка числа: fail или null с записью количества в manifest.
        high_cardinality_action="report",   # report -> unknown; exclude -> excluded; fail -> остановка.
        max_categorical_cardinality=1000,   # Порог различных строковых значений на fit-срезе.
        string_text_length=80,             # Средняя длина строки, начиная с которой роль text.
        unknown_action="keep",              # keep/exclude/fail — что делать с неоднозначной ролью?
    ),
    rules=RuleConfig(rules=(), example_rows=10),  # Здесь Rule с Polars Expr и явным keep/quarantine.
    profiling=ProfilingConfig(
        enabled=True,
        sample_rows=100_000,                # None — полный профиль; иначе первые N строк, явно head.
        quantiles=(0.01, 0.25, 0.5, 0.75, 0.99),
        top_k=10,                          # Сколько частых значений/паттернов показывать?
        missingness=True,
        missingness_columns=(),            # Для каких колонок исследовать пропуски? Пусто — все.
        missingness_pairs=(),              # Какие пары проверить на совместные пропуски?
        segment_columns=(),                # Зарезервировано старым API; используйте drift.segment_columns.
    ),
    missing=MissingConfig(numeric="median", categorical="constant", categorical_value="__MISSING__",
                          text_value="", add_indicator=True),  # Как заполнять пропуски и создавать флаги?
    numeric=NumericConfig(dtype="float32", scaling="none", winsorize=None, clip={}, log1p=(), quantile_bins={}),
    categorical=CategoricalConfig(default_strategy="native", overrides={}, normalize_case=True,
                                  strip=True, rare_min_fraction=0.0, max_one_hot_categories=20),
    # Категории: native/ordinal/frequency/one_hot; статистики только по fit-выборке.
    datetime=DatetimeConfig(components=("year", "month", "weekday"), cyclical=(), drop_original=False),
    text=TextConfig(enabled=True, features=("length", "words", "digit_ratio", "special_count", "is_empty"), drop_original=True),
    leakage=LeakageConfig(enabled=True, check_sample_overlap=True, check_temporal_order=False),
    # Включайте временную проверку только если выборки действительно последовательны во времени.
    duplicates=DuplicateConfig(enabled=True, key_columns=(), action="keep"),
    # key_columns: по какому ключу искать дубли? Пусто — все значения, кроме служебных.
    drift=DriftConfig(
        enabled=False, reference_sample="train", comparison_samples=("valid", "test", "oos", "oot"),
        columns=(),                        # Явный список имеет приоритет над лимитом max_features.
        selection="random",                 # first/random/all — как выбирать признаки?
        max_features=100, seed=42,
        max_rows_per_sample=200_000,        # Первые N строк каждой выборки; факт охвата — в отчёте.
        bins=10, warning=0.10, critical=0.25,
        segment_columns=(),                # Колонки для таблиц размеров сегментов и target rate.
    ),
    quality_gates=QualityGateConfig(
        enabled=True, fail_on_schema_error=True,
        max_invalid_row_rate=1.0, max_duplicate_rate=1.0, max_new_category_rate=1.0,
        max_quarantined_rows=100_000,       # Пороги выше — исходные значения, не универсальные нормы.
        max_sample_overlap_issues=None,    # Число critical-событий; None — не блокировать.
        max_temporal_overlap_issues=None,
        max_critical_drift_issues=None,
        max_issue_counts={"row_key": 0},    # Имя проверки -> допустимое число событий любой severity.
        # Например, ambiguous_role: 0 — блокировать результат при нерешённых ролях.
    ),
    quarantine=QuarantineConfig(enabled=True, schema_violations=True, rule_violations=True, trace_transformations=False),
    lineage=LineageConfig(baseline_path=None, compare_previous=True),
    progress=ProgressConfig(enabled=True, display="auto", persist_events=True),
    resources=ResourceConfig(
        execution="supervised",             # Изолированный run с контролем ресурсов.
        cpu_threads=None,                  # Число потоков Polars; None — выбор runtime.
        ram_limit_gb=None,                 # RSS рабочего процесса, GiB; None — без RAM-бюджета.
        max_runtime_hours=24,             # Лимит run, включая запуск процесса, до публикации.
        poll_interval_seconds=0.2,         # Частота контроля. RAM может кратковременно превысить порог.
        gpu_enabled=False, gpu_devices=(), gpu_memory_limit_gb=None,
        # В 1.2 GPU не поддерживается: запрос отклоняется до чтения данных.
    ),
    reporting=ReportingConfig(enabled=True, html=True),
    output=OutputConfig(path="/data/prepared", rows_per_file=500_000,
                        partition_columns=("sample",), compression="zstd", overwrite=False),
)
