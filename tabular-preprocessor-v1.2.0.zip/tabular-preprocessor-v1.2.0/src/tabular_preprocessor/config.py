from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal, get_args, get_origin, get_type_hints

Role = Literal[
    "numeric", "categorical", "ordinal", "binary", "datetime", "text",
    "id", "target", "technical", "excluded", "unknown",
]


@dataclass(frozen=True)
class InputConfig:
    paths: tuple[str, ...] = ()
    format: Literal["parquet", "csv", "ipc"] = "parquet"
    columns: tuple[str, ...] | None = None
    row_index: str | None = None
    csv_separator: str = ","
    layout: Literal["files", "sample_directories", "sample_paths"] = "files"
    samples: tuple[str, ...] = ()
    sample_paths: dict[str, tuple[str, ...]] = field(default_factory=dict)
    sample_column: str = "sample"
    file_pattern: str = "**/*.parquet"
    checksum: bool = True


@dataclass(frozen=True)
class TaskConfig:
    observation_unit: str | None = None
    prediction_time_column: str | None = None
    available_after_prediction: tuple[str, ...] = ()
    target: str | None = None
    task_type: Literal["binary", "multiclass", "regression", "unsupervised"] = "unsupervised"
    id_columns: tuple[str, ...] = ()
    date_column: str | None = None
    excluded_columns: tuple[str, ...] = ()


@dataclass(frozen=True)
class OutputConfig:
    path: str
    format: Literal["parquet"] = "parquet"
    partition_columns: tuple[str, ...] = ("sample",)
    compression: str = "zstd"
    rows_per_file: int = 1_000_000
    overwrite: bool = False


@dataclass(frozen=True)
class SchemaConfig:
    unknown_action: Literal["keep", "exclude", "fail"] = "keep"
    decimal_separator: Literal[".", ","] = "."
    thousands_separator: str | None = None
    numeric_null_values: tuple[str, ...] = ("",)
    leading_zeros: Literal["preserve", "allow"] = "preserve"
    numeric_parse_errors: Literal["fail", "null"] = "fail"
    numeric_strings: Literal["suggest", "convert", "keep"] = "suggest"
    high_cardinality_action: Literal["report", "exclude", "fail"] = "report"
    numeric_string_min_fraction: float = 1.0
    inference_rows: int = 100_000
    explicit_roles: dict[str, Role] = field(default_factory=dict)
    role_patterns: dict[str, Role] = field(default_factory=dict)
    required_columns: tuple[str, ...] = ()
    nullable: dict[str, bool] = field(default_factory=dict)
    ranges: dict[str, tuple[float | None, float | None]] = field(default_factory=dict)
    allowed_values: dict[str, tuple[object, ...]] = field(default_factory=dict)
    casts: dict[str, str] = field(default_factory=dict)
    string_text_length: int = 80
    max_categorical_cardinality: int | None = 1_000
    policy: Literal["exact", "backward", "permissive"] = "permissive"
    expected_schema: dict[str, str] = field(default_factory=dict)
    preserve_column_order: bool = False


@dataclass(frozen=True)
class Rule:
    name: str
    expression: Any
    severity: Literal["info", "warning", "error", "critical"] = "error"
    max_failure_rate: float = 0.0
    action: Literal["keep", "quarantine"] = "quarantine"
    column: str | None = None
    reason: str = "rule violation"


@dataclass(frozen=True)
class RuleConfig:
    rules: tuple[Rule, ...] = ()
    example_rows: int = 10


@dataclass(frozen=True)
class ProfilingConfig:
    enabled: bool = True
    sample_rows: int | None = 100_000
    quantiles: tuple[float, ...] = (0.01, 0.25, 0.5, 0.75, 0.99)
    top_k: int = 10
    missingness: bool = True
    missingness_columns: tuple[str, ...] = ()
    missingness_pairs: tuple[tuple[str, str], ...] = ()
    segment_columns: tuple[str, ...] = ()


@dataclass(frozen=True)
class SplitConfig:
    group_columns: tuple[str, ...] = ()
    method: Literal["none", "existing", "random", "stratified", "group", "temporal", "group_temporal"] = "none"
    sample_column: str = "sample"
    allowed_samples: tuple[str, ...] = ("train", "valid", "test")
    fractions: tuple[float, ...] = (0.7, 0.15, 0.15)
    group_column: str | None = None
    date_column: str | None = None
    boundaries: tuple[str, ...] = ()
    seed: int = 42


@dataclass(frozen=True)
class MissingConfig:
    numeric: Literal["median", "mean", "zero", "none"] = "median"
    categorical: Literal["most_frequent", "constant", "none"] = "constant"
    categorical_value: str = "__MISSING__"
    text_value: str = ""
    add_indicator: bool = True


@dataclass(frozen=True)
class NumericConfig:
    dtype: Literal["float32", "float64"] = "float32"
    scaling: Literal["none", "standard", "robust"] = "none"
    winsorize: tuple[float, float] | None = None
    clip: dict[str, tuple[float | None, float | None]] = field(default_factory=dict)
    log1p: tuple[str, ...] = ()
    quantile_bins: dict[str, int] = field(default_factory=dict)


@dataclass(frozen=True)
class CategoricalConfig:
    default_strategy: Literal["native", "ordinal", "frequency", "one_hot"] = "native"
    overrides: dict[str, Literal["native", "ordinal", "frequency", "one_hot"]] = field(default_factory=dict)
    normalize_case: bool = True
    strip: bool = True
    rare_min_fraction: float = 0.0
    max_one_hot_categories: int = 20


@dataclass(frozen=True)
class DatetimeConfig:
    components: tuple[str, ...] = ("year", "month", "weekday")
    cyclical: tuple[str, ...] = ()
    drop_original: bool = False


@dataclass(frozen=True)
class TextConfig:
    enabled: bool = True
    features: tuple[str, ...] = ("length", "words", "digit_ratio", "special_count", "is_empty")
    drop_original: bool = True


@dataclass(frozen=True)
class LeakageConfig:
    enabled: bool = True
    near_constant_fraction: float = 0.995
    check_sample_overlap: bool = True
    check_temporal_order: bool = True


@dataclass(frozen=True)
class DuplicateConfig:
    enabled: bool = True
    key_columns: tuple[str, ...] = ()
    action: Literal["keep", "quarantine"] = "keep"


@dataclass(frozen=True)
class DriftConfig:
    selection: Literal["first", "random", "all"] = "first"
    seed: int = 42
    enabled: bool = False
    reference_sample: str = "train"
    comparison_samples: tuple[str, ...] = ("valid", "test", "oos", "oot")
    warning: float = 0.10
    critical: float = 0.25
    bins: int = 10
    max_rows_per_sample: int = 200_000
    segment_columns: tuple[str, ...] = ()
    columns: tuple[str, ...] = ()
    max_features: int | None = 100


@dataclass(frozen=True)
class QuarantineConfig:
    enabled: bool = True
    schema_violations: bool = True
    rule_violations: bool = True
    trace_transformations: bool = False


@dataclass(frozen=True)
class QualityGateConfig:
    max_issue_counts: dict[str, int] = field(default_factory=dict)
    max_sample_overlap_issues: int | None = None
    max_temporal_overlap_issues: int | None = None
    max_critical_drift_issues: int | None = None
    enabled: bool = True
    fail_on_schema_error: bool = True
    max_invalid_row_rate: float = 1.0
    max_duplicate_rate: float = 1.0
    max_new_category_rate: float = 1.0
    max_quarantined_rows: int = 100_000


@dataclass(frozen=True)
class LineageConfig:
    baseline_path: str | None = None
    compare_previous: bool = True


@dataclass(frozen=True)
class ProgressConfig:
    enabled: bool = True
    display: Literal["auto", "none", "console", "jupyter"] = "auto"
    update_interval_seconds: float = 1.0
    persist_events: bool = True


@dataclass(frozen=True)
class ResourceConfig:
    execution: Literal["supervised", "in_process"] = "supervised"
    cpu_threads: int | None = None
    ram_limit_gb: float | None = None
    gpu_enabled: bool = False
    gpu_devices: tuple[str, ...] = ()
    gpu_memory_limit_gb: float | None = None
    max_runtime_hours: float | None = 24.0
    poll_interval_seconds: float = 0.2
    threads: int | None = None
    memory_limit_gb: float | None = None


@dataclass(frozen=True)
class IdentityConfig:
    row_key: tuple[str, ...] = ()
    entity_key: tuple[str, ...] = ()
    group_key: tuple[str, ...] = ()
    business_key: tuple[str, ...] = ()
    technical_columns: tuple[str, ...] = ()


@dataclass(frozen=True)
class SampleConfig:
    fit_sample: str | None = None
    purposes: dict[str, str] = field(default_factory=dict)
    temporal_order: tuple[str, ...] = ()
    allow_entity_overlap: bool = True
    allow_group_overlap: bool = False


@dataclass(frozen=True)
class ReportingConfig:
    enabled: bool = True
    html: bool = True


@dataclass(frozen=True)
class ProjectConfig:
    input: InputConfig
    task: TaskConfig
    output: OutputConfig
    identity: IdentityConfig = field(default_factory=IdentityConfig)
    samples: SampleConfig = field(default_factory=SampleConfig)
    schema: SchemaConfig = field(default_factory=SchemaConfig)
    rules: RuleConfig = field(default_factory=RuleConfig)
    profiling: ProfilingConfig = field(default_factory=ProfilingConfig)
    split: SplitConfig = field(default_factory=SplitConfig)
    missing: MissingConfig = field(default_factory=MissingConfig)
    numeric: NumericConfig = field(default_factory=NumericConfig)
    categorical: CategoricalConfig = field(default_factory=CategoricalConfig)
    datetime: DatetimeConfig = field(default_factory=DatetimeConfig)
    text: TextConfig = field(default_factory=TextConfig)
    leakage: LeakageConfig = field(default_factory=LeakageConfig)
    duplicates: DuplicateConfig = field(default_factory=DuplicateConfig)
    drift: DriftConfig = field(default_factory=DriftConfig)
    quarantine: QuarantineConfig = field(default_factory=QuarantineConfig)
    quality_gates: QualityGateConfig = field(default_factory=QualityGateConfig)
    lineage: LineageConfig = field(default_factory=LineageConfig)
    progress: ProgressConfig = field(default_factory=ProgressConfig)
    resources: ResourceConfig = field(default_factory=ResourceConfig)
    reporting: ReportingConfig = field(default_factory=ReportingConfig)

    def validate(self) -> None:
        import math
        from dataclasses import fields, is_dataclass
        def literals(obj, prefix=""):
            for f in fields(obj):
                value, hint = getattr(obj, f.name), get_type_hints(type(obj))[f.name]
                if get_origin(hint) is Literal and value not in get_args(hint):
                    raise ValueError(f"{prefix}{f.name}: выберите {get_args(hint)}")
                if is_dataclass(value):
                    literals(value, f"{prefix}{f.name}.")
        literals(self)
        labels = (self.input.samples or tuple(self.input.sample_paths)) if self.input.layout != "files" else self.split.allowed_samples
        if self.samples.fit_sample and self.samples.fit_sample not in labels:
            raise ValueError("samples.fit_sample: укажите одну из объявленных выборок")
        if set(self.samples.temporal_order) - set(labels) or set(self.samples.purposes) - set(labels):
            raise ValueError("samples: порядок и назначения содержат неизвестные выборки")
        if self.samples.temporal_order and not (self.task.date_column or self.split.date_column):
            raise ValueError("samples.temporal_order: какая колонка содержит дату? Задайте task.date_column")
        if any(not isinstance(n, int) or n < 0 for n in self.quality_gates.max_issue_counts.values()):
            raise ValueError("quality_gates.max_issue_counts: требуются неотрицательные целые числа")
        r = self.resources
        for name in ("cpu_threads", "threads", "ram_limit_gb", "memory_limit_gb", "max_runtime_hours", "poll_interval_seconds"):
            value = getattr(r, name)
            if value is not None and (not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0):
                raise ValueError(f"resources.{name}: укажите положительное число или None")
        if any(v is not None and (isinstance(v, bool) or not isinstance(v, int)) for v in (r.cpu_threads, r.threads)):
            raise ValueError("resources.cpu_threads: требуется целое число")
        if r.cpu_threads is not None and r.threads is not None or r.ram_limit_gb is not None and r.memory_limit_gb is not None:
            raise ValueError("resources: задайте новое имя параметра либо старый alias, но не оба")
        if r.gpu_enabled or r.gpu_devices or r.gpu_memory_limit_gb is not None:
            raise ValueError("resources: версия 1.2 использует CPU; GPU-параметры пока не поддерживаются")
        if r.execution == "in_process" and any(v is not None for v in (r.cpu_threads, r.threads, r.ram_limit_gb, r.memory_limit_gb, r.max_runtime_hours)):
            raise ValueError("resources: для лимитов выберите execution='supervised'; без лимитов задайте max_runtime_hours=None")
        if self.schema.thousands_separator == self.schema.decimal_separator:
            raise ValueError("schema: десятичный разделитель и разделитель тысяч должны различаться")
        if self.schema.thousands_separator is not None and len(self.schema.thousands_separator) != 1:
            raise ValueError("schema.thousands_separator: один символ или None")
        if self.drift.max_features is not None and self.drift.max_features < 1:
            raise ValueError("drift.max_features: положительное число или None")
        if self.drift.bins < 2 or self.drift.max_rows_per_sample < 1:
            raise ValueError("drift: bins >= 2, max_rows_per_sample > 0")
        if self.profiling.sample_rows is not None and self.profiling.sample_rows < 1:
            raise ValueError("profiling.sample_rows: положительное число или None")
        if self.profiling.segment_columns:
            raise ValueError("profiling.segment_columns пока не реализован; используйте drift.segment_columns")
        if set(self.schema.explicit_roles.values()) - set(get_args(Role)) or set(self.schema.role_patterns.values()) - set(get_args(Role)):
            raise ValueError("schema: неизвестная роль колонки")
        if set(self.task.available_after_prediction) & {c for c, role in self.schema.explicit_roles.items() if role != "excluded"}:
            raise ValueError("task.available_after_prediction конфликтует с явной ролью; такие признаки должны быть excluded")
        if self.task.task_type != "unsupervised" and not self.task.target:
            raise ValueError("task.target: какая колонка содержит целевой показатель?")
        if not self.split.allowed_samples or len(set(self.split.allowed_samples)) != len(self.split.allowed_samples):
            raise ValueError("split.allowed_samples: задайте непустой список уникальных названий")
        if self.schema.numeric_strings not in {"suggest", "convert", "keep"}:
            raise ValueError("schema.numeric_strings: выберите suggest, convert или keep")
        if self.schema.high_cardinality_action not in {"report", "exclude", "fail"}:
            raise ValueError("schema.high_cardinality_action: выберите report, exclude или fail")
        if not 0 < self.schema.numeric_string_min_fraction <= 1 or self.schema.inference_rows < 1:
            raise ValueError("schema: доля числовых строк должна быть в (0, 1], inference_rows > 0")
        for limit in (self.quality_gates.max_sample_overlap_issues, self.quality_gates.max_temporal_overlap_issues, self.quality_gates.max_critical_drift_issues):
            if limit is not None and limit < 0:
                raise ValueError("quality_gates: допустимое число проблем — неотрицательное или None")
        if self.input.layout == "files" and not self.input.paths:
            raise ValueError("input.paths is empty")
        if self.input.layout == "sample_directories" and (not self.input.paths or not self.input.samples):
            raise ValueError("sample_directories requires input.paths and input.samples")
        if self.input.layout == "sample_paths" and not self.input.sample_paths:
            raise ValueError("sample_paths layout requires input.sample_paths")
        if self.output.rows_per_file < 1:
            raise ValueError("output.rows_per_file must be positive")
        if self.schema.max_categorical_cardinality is not None and self.schema.max_categorical_cardinality < 1:
            raise ValueError("schema.max_categorical_cardinality must be positive or None")
        if self.split.method in {"random", "stratified", "group"}:
            if len(self.split.fractions) != len(self.split.allowed_samples):
                raise ValueError("split.fractions and allowed_samples must have equal length")
            if abs(sum(self.split.fractions) - 1) > 1e-9:
                raise ValueError("split.fractions must sum to 1")
        if self.split.method in {"group", "group_temporal"} and not (self.split.group_column or self.split.group_columns or self.identity.group_key):
            raise ValueError("group_column is required")
        if self.split.method in {"temporal", "group_temporal"}:
            if not (self.split.date_column or self.task.date_column):
                raise ValueError("date_column is required")
            if len(self.split.boundaries) != len(self.split.allowed_samples) - 1:
                raise ValueError("temporal boundaries count must be samples count minus one")
        if self.split.method == "stratified" and not self.task.target:
            raise ValueError("target is required for stratified split")
        rates = (
            self.quality_gates.max_invalid_row_rate,
            self.quality_gates.max_duplicate_rate,
            self.quality_gates.max_new_category_rate,
        )
        if any(not 0 <= x <= 1 for x in rates):
            raise ValueError("quality gate rates must be between 0 and 1")
        if Path(self.output.path).resolve() in {Path("/").resolve(), Path.home().resolve()}:
            raise ValueError("unsafe output path")
