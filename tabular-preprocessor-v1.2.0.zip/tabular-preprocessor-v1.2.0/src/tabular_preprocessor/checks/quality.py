import polars as pl

from ..config import ProjectConfig
from ..transformations.core import _category
from ..transformations.state import PipelineState


def check_quality(lf: pl.LazyFrame, config: ProjectConfig, roles: dict[str, str] | None = None) -> tuple[list[dict], dict]:
    issues: list[dict] = []
    sample = config.split.sample_column
    schema = lf.collect_schema()
    rows = lf.select(pl.len()).collect().item()
    stats = {"rows": rows, "duplicate_rows": 0, "duplicate_rate": 0.0}
    roles = roles or {}
    if config.identity.row_key:
        key = list(config.identity.row_key)
        invalid = lf.select((pl.any_horizontal([pl.col(c).is_null() for c in key]) | pl.struct(key).is_duplicated()).sum()).collect().item()
        if invalid:
            issues.append(_issue("row_key", "critical", ",".join(key), f"{invalid} rows have missing or nonunique row keys", "review row identity"))
    for column, role in roles.items():
        if role == "excluded" and column not in config.task.excluded_columns and column not in config.schema.explicit_roles:
            issues.append(_issue("excluded_column", "info", column, "column has excluded role; see role_decisions for policy and evidence", "review role_decisions"))
    if config.duplicates.enabled:
        excluded = {sample, "__tp_row_id"}
        subset = list(config.duplicates.key_columns) or [c for c in schema if c not in excluded]
        duplicate_rows = lf.select(pl.struct(subset).is_duplicated().sum()).collect().item() if subset else 0
        stats |= {"duplicate_rows": duplicate_rows, "duplicate_rate": duplicate_rows / rows if rows else 0.0}
        if duplicate_rows:
            issues.append(_issue("duplicates", "warning", None, f"{duplicate_rows} duplicate rows", "review duplicates"))
    if not config.leakage.enabled:
        return issues, stats
    counts = lf.select(pl.len().alias("rows"), *[pl.col(c).approx_n_unique().alias(c) for c in schema]).collect().row(0, named=True)
    for column in schema:
        if column in {sample, "__tp_row_id"}:
            continue
        if roles.get(column) in {"excluded", "technical", "id", "target"}:
            continue
        if counts[column] <= 1:
            issues.append(_issue("constant", "warning", column, "constant column", "exclude column"))
        elif counts[column] / counts["rows"] >= config.leakage.near_constant_fraction and column not in config.task.id_columns:
            issues.append(_issue("possible_id", "warning", column, "almost every value is unique", "review role"))
    target = config.task.target
    if target and target in schema:
        candidates = [c for c in schema if c not in {target, sample, "__tp_row_id"} and schema[c] == schema[target]]
        if candidates:
            equal = lf.select([(pl.col(c) == pl.col(target)).fill_null(False).all().alias(c) for c in candidates]).collect().row(0, named=True)
            for column, copied in equal.items():
                if copied:
                    issues.append(_issue("target_copy", "critical", column, "exact copy of target", "exclude column"))
    if sample in schema and config.leakage.check_sample_overlap:
        keys = [("row", config.identity.row_key)]
        if not config.samples.allow_entity_overlap:
            keys.append(("entity", config.identity.entity_key))
        if not config.samples.allow_group_overlap:
            keys.append(("group", config.identity.group_key))
        if not any((config.identity.row_key, config.identity.entity_key, config.identity.group_key)):
            keys.extend(("legacy_id", (c,)) for c in config.task.id_columns)
        for kind, columns in keys:
            if not columns:
                continue
            overlap = lf.group_by(list(columns)).agg(pl.col(sample).n_unique().alias("n")).filter(pl.col("n") > 1).select(pl.len()).collect().item()
            if overlap:
                issues.append(_issue("sample_overlap", "critical", ",".join(columns), f"{overlap} {kind} keys occur in several samples", "review sample contract"))
        value_columns = [c for c in schema if c not in {sample, "__tp_row_id"}]
        if value_columns:
            cross = lf.select(pl.struct(value_columns).hash().alias("__hash"), sample).group_by("__hash").agg(pl.col(sample).n_unique().alias("samples")).filter(pl.col("samples") > 1).select(pl.len()).collect().item()
            if cross:
                issues.append(_issue("cross_sample_duplicates", "critical", None, f"{cross} exact records occur in several samples", "remove split leakage"))
    if config.duplicates.key_columns and target and target in schema:
        conflicts = lf.group_by(config.duplicates.key_columns).agg(pl.col(target).n_unique().alias("targets")).filter(pl.col("targets") > 1).select(pl.len()).collect().item()
        if conflicts:
            issues.append(_issue("conflicting_duplicates", "critical", target, f"{conflicts} duplicate keys have conflicting targets", "review labels"))
    if sample in schema and config.leakage.check_temporal_order and config.task.date_column:
        order = lf.group_by(sample).agg(pl.col(config.task.date_column).min().alias("min"), pl.col(config.task.date_column).max().alias("max")).collect()
        labels = [label for label in (config.samples.temporal_order or config.split.allowed_samples) if label in order[sample].to_list()]
        ranges = {row[sample]: row for row in order.iter_rows(named=True)}
        for left, right in zip(labels, labels[1:]):
            if ranges[left]["max"] is not None and ranges[right]["min"] is not None and ranges[left]["max"] > ranges[right]["min"]:
                issues.append(_issue("temporal_overlap", "critical", config.task.date_column, f"{left} overlaps {right}", "review temporal split"))
    return issues, stats


def new_category_rate(lf: pl.LazyFrame, state: PipelineState, config: ProjectConfig | None = None) -> float:
    expressions = []
    for column, params in state.categorical.items():
        value = _category(pl.col(column), config) if config else pl.col(column).cast(pl.String, strict=False)
        expressions.append((~value.is_in(params["known"]) & pl.col(column).is_not_null()).sum().alias(column))
    if not expressions:
        return 0.0
    counts = lf.select(pl.len().alias("rows"), *expressions).collect().row(0, named=True)
    return sum(counts[column] for column in state.categorical) / (counts["rows"] * len(state.categorical)) if counts["rows"] else 0.0


def _issue(check: str, severity: str, column: str | None, reason: str, action: str) -> dict:
    return {"check": check, "severity": severity, "column": column, "sample": None,
            "row_id": None, "reason": reason, "recommended_action": action}
