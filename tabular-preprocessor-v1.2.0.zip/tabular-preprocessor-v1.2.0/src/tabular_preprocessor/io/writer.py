import hashlib
import os
import shutil
from pathlib import Path
from uuid import uuid4

import polars as pl

from ..config import OutputConfig


def staging_directory(config: OutputConfig) -> tuple[Path, Path]:
    output = Path(config.path).resolve()
    if output.exists() and not config.overwrite:
        raise FileExistsError(f"Output already exists: {output}")
    stage = output.parent / f".{output.name}.tmp-{uuid4().hex}"
    stage.mkdir(parents=True)
    return output, stage


def write_dataset(lf: pl.LazyFrame, root: Path, config: OutputConfig) -> list[dict]:
    missing = set(config.partition_columns) - set(lf.collect_schema().names())
    if missing:
        raise ValueError(f"Missing partition columns: {sorted(missing)}")
    sinked = []
    lf.sink_parquet(
        pl.PartitionBy(
            root / "data", key=list(config.partition_columns), include_key=False,
            max_rows_per_file=config.rows_per_file, approximate_bytes_per_file=None,
        ),
        compression=config.compression, maintain_order=True, mkdir=True, engine="streaming",
        sinked_paths_callback=lambda result: sinked.extend(result.paths),
    )
    return [{
        "path": str(Path(item.path).relative_to(root)), "rows": item.num_rows,
        "bytes": item.num_bytes, "sha256": hashlib.sha256(Path(item.path).read_bytes()).hexdigest(),
    } for item in sorted(sinked, key=lambda item: item.path)]


def commit(output: Path, stage: Path, overwrite: bool) -> None:
    if output.exists() and not overwrite:
        raise FileExistsError(f"Output already exists: {output}")
    backup = output.parent / f".{output.name}.backup-{uuid4().hex}"
    if output.exists():
        os.replace(output, backup)
    try:
        os.replace(stage, output)
    except Exception:
        if backup.exists():
            os.replace(backup, output)
        raise
    if overwrite and backup.exists():
        shutil.rmtree(backup)
