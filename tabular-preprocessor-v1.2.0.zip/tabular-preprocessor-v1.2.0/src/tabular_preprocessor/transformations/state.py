import json
from dataclasses import asdict, dataclass, field
from pathlib import Path


@dataclass
class PipelineState:
    version: str = "1.2.0"
    format_version: int = 2
    transform_config: dict = field(default_factory=dict)
    role_decisions: list = field(default_factory=list)
    roles: dict[str, str] = field(default_factory=dict)
    input_schema: dict[str, str] = field(default_factory=dict)
    output_schema: dict[str, str] = field(default_factory=dict)
    numeric: dict[str, dict] = field(default_factory=dict)
    categorical: dict[str, dict] = field(default_factory=dict)

    def save(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(asdict(self), ensure_ascii=False, indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: str | Path) -> "PipelineState":
        values = json.loads(Path(path).read_text(encoding="utf-8"))
        if values.get("format_version", 1) not in (1, 2):
            raise ValueError("Неподдерживаемая версия state")
        return cls(**values)
